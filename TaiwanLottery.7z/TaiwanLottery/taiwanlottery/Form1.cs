﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace taiwanlottery
{
    public partial class Form1 : Form
    {
        string str_txt = "一券在手 希望無窮  ";
        Random random = new Random();
        List <Button> myDButtonList = new List<Button>();
        List<int> clickButtonList = new List<int>();//選到按鈕的號碼
        List<int> clickButtonList2 = new List<int>();//對獎按鈕的號碼
        int[] randomArray = new int[12];//使用者選號
        int[] randomArray2 = new int[12];//對獎
        int click1 = 0;
        string strMsg = "";
   

        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            動態產生按鈕(3,10);
            myDButtonList[29].Visible = false;
            myDButtonList[28].Visible = false;
            myDButtonList[27].Visible = false;
            myDButtonList[26].Visible = false;
            myDButtonList[25].Visible = false;
            myDButtonList[24].Visible = false;
        }

        private void btn電腦快選_Click(object sender, EventArgs e)
        {
            
            Random rnd = new Random();  //產生亂數初始值
            flashEffect();//呼叫動畫效果

            //每次執行一次 就先清空所有資料
            for (int i = 0; i < myDButtonList.Count; i++)
            {
                myDButtonList[i].BackColor = Color.PowderBlue;
            }
            tb您的號碼.Text = "";
            tb本期頭獎.Text = "";
            clickButtonList.Clear();
            strMsg = "";


            //產生亂數不重複
            for (int i = 0; i < 12; i+=1)
            {
                randomArray[i] = rnd.Next(1, 24);

                for (int j = 0; j < i; j+=1)
                {
                    while (randomArray[j] == randomArray[i])//檢查是否與前面產生的數值發生重複，如果有就重新產生
                    {
                        j = 0;  //如有重複，將變數j設為0，再次檢查 (因為還是有重複的可能)
                        randomArray[i] = rnd.Next(1, 24);   //重新產生，存回陣列，亂數產生的範圍是1~24
                    }
                }                               

                myDButtonList[randomArray[i]-1].BackColor = Color.Orange;
                //MessageBox.Show(randomArray[i].ToString());              
            }
            
            clickButtonList.AddRange(randomArray);
            
            clickButtonList.Sort();
            
            for (int i = 0; i < clickButtonList.Count; i++)
            {
                tb您的號碼.Text += clickButtonList[i] + "  ";
            }           
        }


        

        private void btn對獎_Click(object sender, EventArgs e)
        {
            Random rnd = new Random();
            
            //每次下對獎 就先清空
            tb本期頭獎.Text = "";
            clickButtonList2.Clear();
            clickButtonList.Intersect(clickButtonList2);
            strMsg = "";

            for (int i = 0; i < 12; i += 1)
            {
                randomArray2[i] = rnd.Next(1, 24);

                for (int j = 0; j < i; j += 1)
                {
                    while (randomArray2[j] == randomArray2[i])//檢查是否與前面產生的數值發生重複，如果有就重新產生
                    {
                        j = 0;  //如有重複，將變數j設為0，再次檢查 (因為還是有重複的可能)
                        randomArray2[i] = rnd.Next(1, 24);   //重新產生，存回陣列，亂數產生的範圍是1~24
                    }
                }

                //myDButtonList[randomArray2[i] - 1].BackColor = Color.Red;
                //MessageBox.Show(randomArray[i].ToString());                                                                
            }
            clickButtonList2.AddRange(randomArray2);

            clickButtonList2.Sort();

            
            //使用者須先選擇號碼才可對獎
            if (clickButtonList.Count>0)
            {
                for (int i = 0; i < clickButtonList2.Count; i++)
                {
                    tb本期頭獎.Text += clickButtonList2[i] + "  ";
                }
            }
            else
            {
                MessageBox.Show("您尚未選擇號碼");  
            }
            

            //透過.Intersect取得兩個List的交集 來判斷是否中獎
            if (clickButtonList.Intersect(clickButtonList2).Count()==12)//若全中(交集=12)
            {               
                
                foreach (var value in clickButtonList.Intersect(clickButtonList2))
                {
                    strMsg += value.ToString()+" ";                 
                }

                MessageBox.Show("您對中的號碼為: "+strMsg+"\n恭喜中頭獎 $15,000,000元");
            }
            else if ((clickButtonList.Intersect(clickButtonList2).Count() == 0)&&(clickButtonList.Count()==12))//若全不中(交集=0) 且 使用者已選了12個號碼
            {
                MessageBox.Show("您幸運地對中0個號碼 恭喜中頭獎 $15,000,000元");
            }
            else if ((clickButtonList.Intersect(clickButtonList2).Count()==11)&&(clickButtonList.Count() == 12))//對中11碼(交集=11) 且 使用者已選了12個號碼
            {
                foreach (var value in clickButtonList.Intersect(clickButtonList2))
                {
                    strMsg += value.ToString() + " ";
                }
                MessageBox.Show("您對中了11個號碼: " + strMsg + "\n恭喜中貳獎 $100,000元");
            }
            else if ((clickButtonList.Intersect(clickButtonList2).Count() == 1)&& (clickButtonList.Count() == 12))//對中1碼(交集=1) 且 使用者已選了12個號碼
            {
                foreach (var value in clickButtonList.Intersect(clickButtonList2))
                {
                    strMsg += value.ToString() + " ";
                }
                MessageBox.Show("您幸運地只對中了1個號碼: "+strMsg+ "\n恭喜中貳獎 $100,000元");

            }
            else if ((clickButtonList.Intersect(clickButtonList2).Count()==10)&& (clickButtonList.Count() == 12))//對中10碼 且 使用者已選了12個號碼
            {
                foreach (var value in clickButtonList.Intersect(clickButtonList2))
                {
                    strMsg += value.ToString()+" ";
                }
                MessageBox.Show("您對中了10個號碼: " + strMsg + "\n恭喜中參獎 $500元");
            }
            else if ((clickButtonList.Intersect(clickButtonList2).Count()==2)&& (clickButtonList.Count() == 12))//對中2碼 且 使用者已選了12個號碼
            {
                foreach (var value in clickButtonList.Intersect(clickButtonList2))
                {
                    strMsg += value.ToString() + " ";
                }
                MessageBox.Show("您幸運地只對中了2個號碼: " + strMsg + "\n恭喜中貳獎 $500元");
            }
            else if ((clickButtonList.Intersect(clickButtonList2).Count() == 9)&& (clickButtonList.Count() == 12))//對中9碼 且 使用者已選了12個號碼
            {
                foreach (var value in clickButtonList.Intersect(clickButtonList2))
                {
                    strMsg += value.ToString() + " ";
                }
                MessageBox.Show("您對中了9個號碼: " + strMsg + "\n恭喜中肆獎 $100元");
            }
            else if ((clickButtonList.Intersect(clickButtonList2).Count() == 3)&& (clickButtonList.Count() == 12))//對中3碼 且 使用者已選了12個號碼
            {
                foreach (var value in clickButtonList.Intersect(clickButtonList2))
                {
                    strMsg += value.ToString() + " ";
                }
                MessageBox.Show("您幸運地只對中了3個號碼: " + strMsg + "\n恭喜中肆獎 $100元");
            }
            else if(((clickButtonList.Intersect(clickButtonList2).Count()>3)&&(clickButtonList.Intersect(clickButtonList2).Count()<9))&& (clickButtonList.Count() == 12))//對中4~8的號碼 且 使用者已選了12個號碼
            {
                foreach (var value in clickButtonList.Intersect(clickButtonList2))
                {
                    strMsg += value.ToString() + " ";
                }
                MessageBox.Show("您對中的號碼為: " + strMsg+"\n請再接再厲喔!");
            }
            else
            {
                MessageBox.Show("請選12個號碼 再試一次吧!", "台灣彩券提醒您", MessageBoxButtons.RetryCancel, MessageBoxIcon.Information);
            }

        }

        private void btn再玩一次_Click(object sender, EventArgs e)
        {
            
            //顏色恢復
            for (int i = 0; i < myDButtonList.Count; i++)
            {
                myDButtonList[i].BackColor = Color.PowderBlue;
            }

            //將TextBox都清空
            tb您的號碼.Text = "";
            tb本期頭獎.Text = "";
            
            //將List清空
            clickButtonList.Clear();
        }


        private void timer1_Tick(object sender, EventArgs e)
        {
            string strLine = str_txt.Substring(0, 1); //第一個字
            str_txt = str_txt.Substring(1, str_txt.Length - 1) + strLine;//新字串每次從第二個字開始抓，然後把之前抓的第一個字補在最後
            lbl跑馬燈.Text = str_txt; //顯示字串
        }

        void 動態產生按鈕(int intCount1, int intCount2)
        {
            for (int i = 0; i < intCount1; i+=1)
            {
                for (int j = 1; j <= intCount2; j+=1)
                {
                    Button dButton = new Button();
                    dButton.BackColor = Color.PowderBlue;
                    dButton.ForeColor = Color.Black;
                    dButton.Location = new Point( 40 * j, 130 + 42 * i);
                    dButton.Size = new Size(40,40);
                    dButton.Text= (i * 10 + j).ToString();
                    dButton.Name= "btn" + i.ToString() + "-" + j.ToString();
                    dButton.Font = new Font("微軟正黑體",14);
                    dButton.Click += new EventHandler(dButton_Click);

                    Controls.Add(dButton);
                    myDButtonList.Add(dButton);
                }
            }
        }

        void dButton_Click(object sender, EventArgs e)
        {
            Button myButton = (Button)sender;

            //按下選號變色
            if (clickButtonList.Count <= 12)
            {
                
                if (myButton.BackColor == Color.PowderBlue)
                {
                    myButton.BackColor = Color.Orange;
                    clickButtonList.Add(Convert.ToInt32(myButton.Text));                                       
                    UpdateNumberListToLabel();//將陣列中的東西 全部指定到Textbox中
                    //tb您的號碼.Text += myButton.Text + "   ";
                }
                else
                {
                    myButton.BackColor = Color.PowderBlue;                    
                    clickButtonList.Remove(Convert.ToInt32(myButton.Text));
                    UpdateNumberListToLabel();                 

                }
            }
            else
            {
                MessageBox.Show("您已選擇12個號碼了!");
            }
            
        }

        //將陣列中的東西 全部指定到Textbox中
        private void UpdateNumberListToLabel()
        {
            tb您的號碼.Text = "";
            clickButtonList.Sort();//將所選號碼排列
            foreach (int item in clickButtonList)
            {
                tb您的號碼.Text += "  " + item.ToString();
            }
            
        }

        //電腦亂數選的動畫效果 Refresh(): 表重新載入
        void flashEffect()
        {
            for (int i = 0; i < 20; i += 1)
            {
                for (int j = 0; j <24; j += 1)
                    myDButtonList[random.Next(1, 24)].BackColor = Color.Orange;

                this.Refresh();

                for (int k = 0; k < 24; k += 1)
                    myDButtonList[k].BackColor = Color.PowderBlue;
            }
        }
        

        private void button1_Click(object sender, EventArgs e)
        {
            Form2 myForm2 = new Form2();
            this.Hide();
            myForm2.ShowDialog();
            
        }
    }
}
