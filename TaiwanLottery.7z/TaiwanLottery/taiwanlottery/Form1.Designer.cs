﻿namespace taiwanlottery
{
    partial class Form1
    {
        /// <summary>
        /// 設計工具所需的變數。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清除任何使用中的資源。
        /// </summary>
        /// <param name="disposing">如果應該處置受控資源則為 true，否則為 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form 設計工具產生的程式碼

        /// <summary>
        /// 此為設計工具支援所需的方法 - 請勿使用程式碼編輯器修改
        /// 這個方法的內容。
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.label1 = new System.Windows.Forms.Label();
            this.tb您的號碼 = new System.Windows.Forms.TextBox();
            this.btn電腦快選 = new System.Windows.Forms.Button();
            this.btn對獎 = new System.Windows.Forms.Button();
            this.btn再玩一次 = new System.Windows.Forms.Button();
            this.lbl跑馬燈 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.tb本期頭獎 = new System.Windows.Forms.TextBox();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.button1 = new System.Windows.Forms.Button();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("微軟正黑體", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label1.ForeColor = System.Drawing.Color.Black;
            this.label1.Location = new System.Drawing.Point(54, 488);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(140, 33);
            this.label1.TabIndex = 1;
            this.label1.Text = "您的號碼 : ";
            // 
            // tb您的號碼
            // 
            this.tb您的號碼.Font = new System.Drawing.Font("微軟正黑體", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.tb您的號碼.Location = new System.Drawing.Point(195, 481);
            this.tb您的號碼.Margin = new System.Windows.Forms.Padding(4);
            this.tb您的號碼.Name = "tb您的號碼";
            this.tb您的號碼.ReadOnly = true;
            this.tb您的號碼.Size = new System.Drawing.Size(483, 36);
            this.tb您的號碼.TabIndex = 2;
            // 
            // btn電腦快選
            // 
            this.btn電腦快選.BackColor = System.Drawing.Color.Gold;
            this.btn電腦快選.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btn電腦快選.FlatAppearance.BorderColor = System.Drawing.Color.Maroon;
            this.btn電腦快選.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.btn電腦快選.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.btn電腦快選.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btn電腦快選.Font = new System.Drawing.Font("微軟正黑體", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.btn電腦快選.ForeColor = System.Drawing.Color.Black;
            this.btn電腦快選.Location = new System.Drawing.Point(236, 383);
            this.btn電腦快選.Margin = new System.Windows.Forms.Padding(4);
            this.btn電腦快選.Name = "btn電腦快選";
            this.btn電腦快選.Size = new System.Drawing.Size(267, 57);
            this.btn電腦快選.TabIndex = 3;
            this.btn電腦快選.Text = "電腦快選";
            this.btn電腦快選.UseVisualStyleBackColor = false;
            this.btn電腦快選.Click += new System.EventHandler(this.btn電腦快選_Click);
            // 
            // btn對獎
            // 
            this.btn對獎.BackColor = System.Drawing.Color.Goldenrod;
            this.btn對獎.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btn對獎.FlatAppearance.BorderColor = System.Drawing.Color.Maroon;
            this.btn對獎.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.btn對獎.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.btn對獎.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btn對獎.Font = new System.Drawing.Font("微軟正黑體", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.btn對獎.ForeColor = System.Drawing.Color.Black;
            this.btn對獎.Location = new System.Drawing.Point(49, 663);
            this.btn對獎.Margin = new System.Windows.Forms.Padding(4);
            this.btn對獎.Name = "btn對獎";
            this.btn對獎.Size = new System.Drawing.Size(240, 57);
            this.btn對獎.TabIndex = 4;
            this.btn對獎.Text = "對獎";
            this.btn對獎.UseVisualStyleBackColor = false;
            this.btn對獎.Click += new System.EventHandler(this.btn對獎_Click);
            // 
            // btn再玩一次
            // 
            this.btn再玩一次.BackColor = System.Drawing.Color.Gold;
            this.btn再玩一次.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btn再玩一次.FlatAppearance.BorderColor = System.Drawing.Color.Maroon;
            this.btn再玩一次.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.btn再玩一次.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.btn再玩一次.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btn再玩一次.Font = new System.Drawing.Font("微軟正黑體", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.btn再玩一次.ForeColor = System.Drawing.Color.Black;
            this.btn再玩一次.Location = new System.Drawing.Point(440, 663);
            this.btn再玩一次.Margin = new System.Windows.Forms.Padding(4);
            this.btn再玩一次.Name = "btn再玩一次";
            this.btn再玩一次.Size = new System.Drawing.Size(238, 57);
            this.btn再玩一次.TabIndex = 5;
            this.btn再玩一次.Text = "再玩一次";
            this.btn再玩一次.UseVisualStyleBackColor = false;
            this.btn再玩一次.Click += new System.EventHandler(this.btn再玩一次_Click);
            // 
            // lbl跑馬燈
            // 
            this.lbl跑馬燈.Font = new System.Drawing.Font("標楷體", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.lbl跑馬燈.ForeColor = System.Drawing.Color.Red;
            this.lbl跑馬燈.Location = new System.Drawing.Point(230, 113);
            this.lbl跑馬燈.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbl跑馬燈.Name = "lbl跑馬燈";
            this.lbl跑馬燈.Size = new System.Drawing.Size(696, 28);
            this.lbl跑馬燈.TabIndex = 6;
            this.lbl跑馬燈.Text = "一券在手 希望無窮";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("微軟正黑體", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label3.ForeColor = System.Drawing.Color.Black;
            this.label3.Location = new System.Drawing.Point(-3, 569);
            this.label3.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(192, 33);
            this.label3.TabIndex = 7;
            this.label3.Text = "本期頭獎號碼 : ";
            // 
            // tb本期頭獎
            // 
            this.tb本期頭獎.Font = new System.Drawing.Font("微軟正黑體", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.tb本期頭獎.Location = new System.Drawing.Point(195, 563);
            this.tb本期頭獎.Margin = new System.Windows.Forms.Padding(4);
            this.tb本期頭獎.Name = "tb本期頭獎";
            this.tb本期頭獎.ReadOnly = true;
            this.tb本期頭獎.Size = new System.Drawing.Size(483, 36);
            this.tb本期頭獎.TabIndex = 8;
            // 
            // timer1
            // 
            this.timer1.Enabled = true;
            this.timer1.Interval = 700;
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(128)))));
            this.button1.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button1.FlatAppearance.BorderColor = System.Drawing.Color.Maroon;
            this.button1.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.button1.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.button1.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button1.Font = new System.Drawing.Font("微軟正黑體", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.button1.ForeColor = System.Drawing.Color.Black;
            this.button1.Location = new System.Drawing.Point(316, 711);
            this.button1.Margin = new System.Windows.Forms.Padding(4);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(100, 57);
            this.button1.TabIndex = 9;
            this.button1.Text = "Help";
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::taiwanlottery.Properties.Resources.schedule_1224;
            this.pictureBox1.Location = new System.Drawing.Point(316, 16);
            this.pictureBox1.Margin = new System.Windows.Forms.Padding(4);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(117, 65);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox1.TabIndex = 0;
            this.pictureBox1.TabStop = false;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Beige;
            this.ClientSize = new System.Drawing.Size(744, 781);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.tb本期頭獎);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.lbl跑馬燈);
            this.Controls.Add(this.btn再玩一次);
            this.Controls.Add(this.btn對獎);
            this.Controls.Add(this.btn電腦快選);
            this.Controls.Add(this.tb您的號碼);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.pictureBox1);
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "Form1";
            this.Text = "雙贏彩 兌獎器";
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox tb您的號碼;
        private System.Windows.Forms.Button btn電腦快選;
        private System.Windows.Forms.Button btn對獎;
        private System.Windows.Forms.Button btn再玩一次;
        private System.Windows.Forms.Label lbl跑馬燈;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox tb本期頭獎;
        private System.Windows.Forms.Timer timer1;
        private System.Windows.Forms.Button button1;
    }
}

