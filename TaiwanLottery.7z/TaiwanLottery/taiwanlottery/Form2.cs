﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Diagnostics;

namespace taiwanlottery
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();
        }

        private void Form2_Load(object sender, EventArgs e)
        {
            label1.Text = "雙贏彩是一種樂透型遊戲，您必須從01~24的號碼中任選12個號碼進行投注。開獎時，開獎單位將隨機開出12個號碼，這一組號碼就是該期雙贏彩的中獎號碼，也稱為「獎號」。您的12個選號如果全部對中當期開出之12個號碼，或者全部未對中，均為中頭獎。";
            
        }

        private void btn回上頁_Click(object sender, EventArgs e)
        {
            Form1 myform = new Form1();
            this.Hide();
            myform.ShowDialog();
        }

        private void btn更多資訊_Click(object sender, EventArgs e)
        {//連結官網
            Process.Start("http://www.taiwanlottery.com.tw/Lotto1224/index.asp");//在檔頭補上引用 using System.Diagnostics;
        }
    }
}
